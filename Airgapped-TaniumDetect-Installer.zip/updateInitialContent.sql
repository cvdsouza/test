use tanium;
update dbo.global_settings set numeric_value='0' where name='load_initial_content';