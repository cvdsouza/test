Airgapped Tanium Content 
===================================================================================================
An "Airgapped" server is one that is purposefully isolated such that it is unable to reach the 
Internet. Installation of Tanium XML content files onto such a server requires additional 
consideration because content such as packages may depend upon files referenced by Remote URIs. An
Internet-facing Tanium server downloads these files directly on the customer's behalf; however,
an airgapped Tanium server will be unable to fetch these file dependencies.

This Zip file provides both a special version of the Tanium XML content file and a set of scripts 
to assist the administrator with fetching the files and staging them locally on the airgapped 
Tanium server.


Installation of Airgapped Tanium Content
===================================================================================================

  1. Copy this Zip file to the Tanium Server, extract it.
  
  2. If not using the Airgap installer DVD, which generates an automatically import-able manifest,
     then you will need to disable the automatic importing of Initial Content.
     Execute the updateInitialContent.sql statement to turn off the initial content download.  You 
     can double-click on the file to open it in SQL Server Management Studio.  Then, right click in 
     the query window and select 'Execute'.
  
  3. Right click on the "Install-Local-Content.bat" file, and select "Run as Administrator".
  
     Remarks:
	 > After running the batch file, an XML content file will be generated that can be imported
	   via the Tanium Console.
	   
	 > Take note of the output line "The content file can now be copied from:", as this indicates
	   the local copy of the file that can be imported into the server.  The file may need to 
	   be moved to a location that is accessible by the browser running as a local user.
	   
	 > Take note of the output line "Remote content must be copied to:", as this indicates the
	   Dropoff directory that will function as the local cache of files. Usually this path will 
	   be of the following form:
	   
		  C:\<Tanium Server Install Dir>\http\content\<solution>\<version>\Dropoff

  4. Import the generated XML content file via the Tanium Console.
  
      4a. Open the Tanium console and login as a user with Content Authoring priviledges. 
      
      4b. Navigate to the "Authoring" tab, and click "Import Content..."

      4c. Browse the filesystem to the Tanium server installation directory and select the 
	      "TaniumDetect.xml.xml" file generated in step 2.
	  
	      Remarks:
		  > The console import operation will download the content's files via the local
		    Tanium web server.
  

Downloading Additional File Dependencies via an Internet-facing Machine
===================================================================================================
Additional files required by the airgapped Tanium content which were not directly included in this
Zip package due to licensing and size restrictions must be downloaded separately. Follow the 
procedure described below to download these additional external files using a machine with external 
Internet access.

  1. Copy the "Download-Remote-Files.bat" script to the Internet-facing machine.
  
  2. Run "Download-Remote-Files.bat".

         Remarks:
         > This script will download to a local directory all of the files required by the server
		 
		 > The file "non-local-files.txt" defines the URIs to be downloaded.

  3. Copy all files in the "FilesToCopyToServer" folder over to the Dropoff directory specified in 
     the output of the airgap install tool from Step 2 of the "Installation of Airgapped Tanium 
	 Content" above.

			
Installation of Airgapped Tanium Content with custom URI and custom destination
===================================================================================================
By default, when run directly with no options, the airgap installer will deliver the content to 
the http file sharing directory of the server, with the first name listed in the 
TrustedHosts list of the Tanium Server registry entry.  This allows a user of the console on the
server to import content, as the server will connect to the URLs and download the content directly
from itself.

It is also possible though to override the root URI used for generating the airgapped content, or 
to override both the root URI and the destination folder to which the package is delivered.  This
allows the setting up an independent content server, that an Active/Active pair both connect to
for the content.  To override the root URI and the destination folder, follow these steps:

  1. Copy this Zip file to the machine on which you want to install the customized airgap 
     content, and extract it.
     
     Remarks:
     > If the destination folder is not specified, only the root URI is specified, the machine
       must have a Tanium Server installed.

  2. Open an Administrator cmd prompt and change to the top level directory of the unzipped
     package.
     
  3. Run:
     Install-Local-Content.bat <rootURI> [destination folder]
     
     Remarks:
     > For example, if the Apache HTTP Server for "myhost.com" is installed at c:\Apache, the
       command line would be:
       Install-Local-Content.bat http://myhost.com/ c:\Apache\htdocs\
     > The destination folder is optional, and if not specified, the Tanium Server's http 
       directory will be used.
     > The same items taken note of in the output of the output of the Airgap installer
       should be used in following steps.
       
  4. Continue on with Step 4. from the standard installation instructions.
					
					
(Initial Content Only) Special Considerations for the Airgapped Patch Management Content 
===================================================================================================			
The "Patch Management" content will still function though airgapped; it expects to find all patch 
files in the same Dropoff directory as used above. The patch files should be downloaded via an
Internet-facing computer and stored in the Dropoff directory before the patch action to deploy 
that patch is created.

The procedure here explains how to quickly fetch required patch files using the download script
in this Zip package.

  1. Within the Tanium console, use the "Required Windows Patches URL" saved question to get the 
     patch file URLs.  
	 
  2. Once the results view is populated, select the Copy button to copy to the results to the 
     system clipboard.
	 
	      Remarks:
		  > You may also choose to export the results to a CSV file.
  
  3. Navigate to the folder containing the Download-Remote-Files tools used above.
  
  4. Modify the "non-local-files.txt" file and paste the copied results from Step 2.
  
          Remarks:
		  > If you chose to export a CSV file instead, you should modify the script
		    Download-Remote-Files-Exported-CSV.bat to point to your CSV file.
  
  5. Run "Download-Remote-Files.bat".
   
          Remarks:
		  > If using a CSV, run the "Download-Remote-Files-Exported-CSV.bat" file.
  
  6. Copy all files from the "FilesToCopyToServer" to the Tanium server's Dropoff directory.
  

Troubleshooting Tips for Common Problems
===================================================================================================  

Problem: Importing the airgapped XML content file into the Tanium console generates an error like
         "Error: Error #2038, ErrorID: 2038", or like "An error occured while importing or exporting 
		 the Dashboard".

		 > Try relocating the generated Tanium XML content file from the Tanium server directory to
		   the server's Desktop folder and try again. Sometimes lock-down security settings on 
		   the server will cause this.

Problem: You cannot login to the Tanium console of an Airgapped Tanium server after installation.

         > By default, the Tanium server ships with the Global setting "load_initial_content" set to
		   "1", which will cause the server to attempt downloading of the initial content when it is
		   started. This will fail due to the lack of Internet-connectivity of the Airgapped server.
		 
		 CAUTION: Always be extra-careful when modifying the Tanium database.
		 > Using the sqlcmd utility:
		   
		     sqlcmd -S .\SQLExpress -i updateInitialContent.sql
		   
             Remarks:
			 > The updateInitialContent.sql file is included in this Zip package
			 
			 > The SQLExpress database instance name may need to be modified if not using this name
