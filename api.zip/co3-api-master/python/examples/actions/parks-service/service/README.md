# Parks Service

To run this web service under OSX or linux:

* [Install Mono](http://www.mono-project.com/download/)
* To start the service, just run `xsp4` from this directory.

You can then interact with the service in a browser at
[http://localhost:9000/cmdb.asmx](http://localhost:9000/cmdb.asmx).
