__author__ = 'IBM Resilient'

from resilient_circuits import app

app.run()
