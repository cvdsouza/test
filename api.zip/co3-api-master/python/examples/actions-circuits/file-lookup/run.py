__author__ = 'IBM Resilient'

import logging
from resilient_circuits import app

app.log(logging.DEBUG)
app.run()
