#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" nosetests --with-coverage --cover-package=co3 """


def test():
    """The most basic tests"""
    from co3 import co3
    from co3 import co3argparse
    from co3 import co3sslutil
    pass
