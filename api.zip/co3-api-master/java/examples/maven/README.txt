This directory contains a simple Resilient REST API example that uses Maven.
