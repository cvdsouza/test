﻿
namespace Co3.Rest.Dto
{
    public enum NewsfeedObjectType
    {
        Incident = 0,
        Task = 1,
        Milestone = 2,
        Artifact = 3,
        DataTable = 4
    }
}
