#!/usr/bin/env python
# -*- coding: utf-8 -*-
from .common import *

from .api4 import *


__version__ = '0.0.2'
__date__ = '2012-01-21'
__author__ = "Marc 'BlackJack' Rintsch, Gleb 'Zhulik' Sinyavsky"
__contact__ = 'marc@rintsch.de, zhulik.gleb@gmail.com'
# 
# Due to lm-sensors 2.x using this license.
# 
__license__ = 'GPL v2'
