=========
Py3Sensors
=========

:author: Marc 'BlackJack' Rintsch, Gleb 'Zhulik' Sinyavsky
:date: 2013-01-21

Python bindings for ``libsensors.so`` from the `lm-sensors`_ project via
`ctypes`. Supported only 4 API version.

Requirements
============

* Python 2.7 or Python ≥3.3
* ``libsensors.so`` from `lm-sensors`_ version 3.x (API 4)

The package is pure Python, so any implementation with the `ctypes` module
should work.

Installation
============

The usual ``python setup.py install`` from within the source distribution.

Links
=====

================= =================================================
Source repository https://bitbucket.org/gleb_zhulik/py3sensors
Bugtracker        https://bitbucket.org/gleb_zhulik/py3sensors/issues/
================= =================================================

Example
=======

The following example prints all detected sensor chips, their adapter, and the features with they ”main” value for each chip::

  import sensors
  
  sensors.init()
  try:
      for chip in sensors.iter_detected_chips():
          print ('%s at %s' % (chip, chip.adapter_name))
          for feature in chip:
              print ('  %s: %.2f' % (feature.label, feature.get_value()))
  finally:
      sensors.cleanup()

Example output of the code above::

  k8temp-pci-00c3 at PCI adapter
    Core0 Temp: 16.00
    Core0 Temp: 11.00
    Core1 Temp: 28.00
    Core1 Temp: 19.00
  w83627ehf-isa-0290 at ISA adapter
    Vcore: 1.10
    in1: 1.10
    AVCC: 3.30
    VCC: 3.31
    in4: 1.68
    in5: 1.68
    in6: 1.86
    3VSB: 3.30
    Vbat: 3.06
    in9: 1.55
    Case Fan: 1231.00
    CPU Fan: 2410.00
    Aux Fan: 0.00
    fan5: 0.00
    Sys Temp: 39.00
    CPU Temp: 31.50
    AUX Temp: 30.50
    cpu0_vid: 0.00

.. _lm-sensors: http://www.lm-sensors.org/